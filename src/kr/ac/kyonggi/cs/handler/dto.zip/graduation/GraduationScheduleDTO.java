package kr.ac.kyonggi.cs.handler.dto.graduation;

import java.util.Date;

public class GraduationScheduleDTO {
	
	private int schedule_id;
	private int schedule_name;
	private String schedule_name_string;
	private Date starting_date;
	private Date closing_date;
	private String schedule_contents;
	
	public int getSchedule_id() {
		return schedule_id;
	}
	public void setSchedule_id(int schedule_id) {
		this.schedule_id = schedule_id;
	}
	public int getSchedule_name() {
		return schedule_name;
	}
	public void setSchedule_name(int schedule_name) {
		this.schedule_name = schedule_name;
	}
	public String getSchedule_name_string() {
		return schedule_name_string;
	}
	public void setSchedule_name_string(String schedule_name_string) {
		this.schedule_name_string = schedule_name_string;
	}
	public Date getStarting_date() {
		return starting_date;
	}
	public void setStarting_date(Date starting_date) {
		this.starting_date = starting_date;
	}
	public Date getClosing_date() {
		return closing_date;
	}
	public void setClosing_date(Date closing_date) {
		this.closing_date = closing_date;
	}
	public String getSchedule_contents() {
		return schedule_contents;
	}
	public void setSchedule_contents(String schedule_contents) {
		this.schedule_contents = schedule_contents;
	}
	
	

}
