package kr.ac.kyonggi.cs.handler.dto.graduation;

public class GraduationReqStudentsDTO {
	
	private int per_id;
	private String name;
	private String prof_name;
	private int capstone;
	private String capstone_string;
	private String graudation_date;
	private String etc_type;
	private String major;
	
	public int getPer_id() {
		return per_id;
	}
	public void setPer_id(int per_id) {
		this.per_id = per_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProf_name() {
		return prof_name;
	}
	public void setProf_name(String prof_name) {
		this.prof_name = prof_name;
	}
	public int getCapstone() {
		return capstone;
	}
	public void setCapstone(int capstone) {
		this.capstone = capstone;
	}
	public String getCapstone_string() {
		return capstone_string;
	}
	public void setCapstone_string(String capstone_string) {
		this.capstone_string = capstone_string;
	}
	public String getGraudation_date() {
		return graudation_date;
	}
	public void setGraudation_date(String graudation_date) {
		this.graudation_date = graudation_date;
	}
	public String getEtc_type() {
		return etc_type;
	}
	public void setEtc_type(String etc_type) {
		this.etc_type = etc_type;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	

}
