package kr.ac.kyonggi.cs.handler.dto.graduation;

import java.util.Date;

public class GraduationEtcStateDTO {
	
	private int per_id;
	private int capstone;
	private String capstone_string;
	private boolean certificate_submit;
	private boolean conference_submit;
	private boolean contest_submit;
	private int certi_level;
	private String certi_level_string;
	private Date certi_date;
	private int confe_level;
	private String confe_leve_string;
	private Date confe_date;
	private int contest_level;
	private String contest_level_string;
	private Date contest_date;
	public int getPer_id() {
		return per_id;
	}
	public void setPer_id(int per_id) {
		this.per_id = per_id;
	}
	public int getCapstone() {
		return capstone;
	}
	public void setCapstone(int capstone) {
		this.capstone = capstone;
	}
	public String getCapstone_string() {
		return capstone_string;
	}
	public void setCapstone_string(String capstone_string) {
		this.capstone_string = capstone_string;
	}
	public boolean isCertificate_submit() {
		return certificate_submit;
	}
	public void setCertificate_submit(boolean certificate_submit) {
		this.certificate_submit = certificate_submit;
	}
	public boolean isConference_submit() {
		return conference_submit;
	}
	public void setConference_submit(boolean conference_submit) {
		this.conference_submit = conference_submit;
	}
	public boolean isContest_submit() {
		return contest_submit;
	}
	public void setContest_submit(boolean contest_submit) {
		this.contest_submit = contest_submit;
	}
	public int getCerti_level() {
		return certi_level;
	}
	public void setCerti_level(int certi_level) {
		this.certi_level = certi_level;
	}
	public String getCerti_level_string() {
		return certi_level_string;
	}
	public void setCerti_level_string(String certi_level_string) {
		this.certi_level_string = certi_level_string;
	}
	public Date getCerti_date() {
		return certi_date;
	}
	public void setCerti_date(Date certi_date) {
		this.certi_date = certi_date;
	}
	public int getConfe_level() {
		return confe_level;
	}
	public void setConfe_level(int confe_level) {
		this.confe_level = confe_level;
	}
	public String getConfe_leve_string() {
		return confe_leve_string;
	}
	public void setConfe_leve_string(String confe_leve_string) {
		this.confe_leve_string = confe_leve_string;
	}
	public Date getConfe_date() {
		return confe_date;
	}
	public void setConfe_date(Date confe_date) {
		this.confe_date = confe_date;
	}
	public int getContest_level() {
		return contest_level;
	}
	public void setContest_level(int contest_level) {
		this.contest_level = contest_level;
	}
	public String getContest_level_string() {
		return contest_level_string;
	}
	public void setContest_level_string(String contest_level_string) {
		this.contest_level_string = contest_level_string;
	}
	public Date getContest_date() {
		return contest_date;
	}
	public void setContest_date(Date contest_date) {
		this.contest_date = contest_date;
	}

}
