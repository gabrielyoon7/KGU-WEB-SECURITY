package kr.ac.kyonggi.cs.handler.stateenum;

public enum State {
	
	Unqualificate(1,"자격없음"),
	Unapproval(2,"전 단계 미승인"),
	Stand(3,"대기"),
	SubmitPossible(4,"제출 가능"),
	Deadline(5,"마감"),
	SubmitComplete(6,"제출 완료"),
	Approval(7,"확인");
	
	final int state;
	final String str;
	
	State(int state,String str){
		this.state=state;
		this.str=str;
	}
	
	public static String getState(int state) {
		String result=null;
		
		for(State s:State.values()) {
			if(s.state==state) {
				result=s.str;
			}
		}
		return result;
	}

}
